// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "GetBPParamsGameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class GETBPPARAMS_API AGetBPParamsGameModeBase : public AGameModeBase
{
	GENERATED_BODY()
	
};
