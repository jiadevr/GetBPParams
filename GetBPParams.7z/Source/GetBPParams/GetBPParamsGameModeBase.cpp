// Copyright Epic Games, Inc. All Rights Reserved.


#include "GetBPParamsGameModeBase.h"

